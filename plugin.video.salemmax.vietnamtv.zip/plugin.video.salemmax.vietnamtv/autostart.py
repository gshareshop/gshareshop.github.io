#!/usr/bin/python
#coding=utf-8

import xbmc, xbmcaddon

addon = xbmcaddon.Addon(id='plugin.video.salemmax.vietnamtv')

if addon.getSetting('autostart') == 'true':
	xbmc.executebuiltin("RunAddon()")